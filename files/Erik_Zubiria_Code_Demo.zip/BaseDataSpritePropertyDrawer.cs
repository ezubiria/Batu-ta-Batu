﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

namespace EZSD {
    [CustomPropertyDrawer(typeof(BaseDataSpriteArray))]
    public class BaseDataSpritePropertyDrawer : PropertyDrawer {
        public bool showPosition = true;
        Rect newposition;
        int allTimes = 0;
        int allCoins = 0;
        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label) {

            allTimes = 0;
            allCoins = 0;
            newposition = position;
            newposition.y += 18f;
            EditorGUI.LabelField(new Rect(position.x, newposition.y, 100, newposition.height), new GUIContent("Sprite"));
            newposition.y += 18f;
            SerializedProperty times = property.FindPropertyRelative("widths");
            SerializedProperty coins = property.FindPropertyRelative("heights");
            GUIStyle style = new GUIStyle();
            style.normal.textColor = new Color(0.7f, 0.4f, 0.96f);
            EditorGUI.LabelField(new Rect(position.x, newposition.y, 100, newposition.height), new GUIContent("Widths"), style);
            style.normal.textColor = new Color(0.7f, 0.2f, 0.2f);
            EditorGUI.LabelField(new Rect(60, newposition.y, 100, newposition.height), new GUIContent("Heights"), style);
            newposition.y += 18f;
            AddTopLabels(position, newposition, times.GetArrayElementAtIndex(0).FindPropertyRelative("cols").arraySize);
            newposition.y += 18f;

            for (int j = times.arraySize - 1; j >= 0; j--) {
                SerializedProperty timesCols = times.GetArrayElementAtIndex(j).FindPropertyRelative("cols");
                SerializedProperty coinsCols = coins.GetArrayElementAtIndex(j).FindPropertyRelative("cols");
                newposition.height = 18f;
                newposition.width = position.width / 22;
                for (int i = -1; i < times.GetArrayElementAtIndex(0).FindPropertyRelative("cols").arraySize; i++) {
                    if (i == -1) {
                        EditorGUI.LabelField(new Rect(newposition.x, newposition.y, 20, newposition.height), new GUIContent((j + 1) + ""));
                        newposition.x += 20;
                    } else {
                        GUI.color = new Color(0.96f, 0.8f, 0.96f);
                        EditorGUI.PropertyField(newposition, timesCols.GetArrayElementAtIndex(i), GUIContent.none);
                        GUI.color = new Color(0.96f, 0.8f, 0.8f);
                        EditorGUI.PropertyField(new Rect(newposition.x + (position.width / 22), newposition.y, newposition.width, 18), coinsCols.GetArrayElementAtIndex(i), GUIContent.none);
                        newposition.x += newposition.width * 2;
                    }
                }
                newposition.x = position.x;
                newposition.y += 18f;
            }

            newposition.y += 18f;
            times = property.FindPropertyRelative("times");
            coins = property.FindPropertyRelative("coins");
            style = new GUIStyle();
            float timesCoinsPos = newposition.y;
            
            newposition.y += 18f;
            AddTopLabels(position, newposition, times.GetArrayElementAtIndex(0).FindPropertyRelative("cols").arraySize);
            newposition.y += 18f;
            for (int j = times.arraySize - 1; j >= 0; j--) {
                SerializedProperty timesCols = times.GetArrayElementAtIndex(j).FindPropertyRelative("cols");
                SerializedProperty coinsCols = coins.GetArrayElementAtIndex(j).FindPropertyRelative("cols");
                newposition.height = 18f;
                newposition.width = position.width / 22;
                for (int i = -1; i < times.GetArrayElementAtIndex(0).FindPropertyRelative("cols").arraySize; i++) {
                    if (i == -1) {
                        EditorGUI.LabelField(new Rect(newposition.x, newposition.y, 20, newposition.height), new GUIContent((j + 1) + ""));
                        newposition.x += 20;
                    } else {
                        GUI.color = new Color(0.8f, 0.8f, 0.96f);
                        EditorGUI.PropertyField(newposition, timesCols.GetArrayElementAtIndex(i), GUIContent.none);
                        allTimes += timesCols.GetArrayElementAtIndex(i).intValue;
                        GUI.color = new Color(0.8f, 0.96f, 0.8f);
                        EditorGUI.PropertyField(new Rect(newposition.x + (position.width / 22), newposition.y, newposition.width, 18), coinsCols.GetArrayElementAtIndex(i), GUIContent.none);
                        allCoins += coinsCols.GetArrayElementAtIndex(i).intValue;
                        newposition.x += newposition.width * 2;
                    }
                }
                newposition.x = position.x;
                newposition.y += 18f;
            }
            style.normal.textColor = new Color(0.4f, 0.4f, 0.96f);
            EditorGUI.LabelField(new Rect(position.x, timesCoinsPos, 100, newposition.height), new GUIContent("Times (" + allTimes + ")"), style);
            style.normal.textColor = new Color(0.2f, 0.7f, 0.2f);
            EditorGUI.LabelField(new Rect(100, timesCoinsPos, 100, newposition.height), new GUIContent("Coins (" + allCoins + ") + (" + (allCoins / 4) + ")"), style);
            EditorGUI.DrawRect(new Rect(position.x, newposition.y + 10, position.width, 1), Color.gray);
        }

        private void AddTopLabels(Rect position, Rect newposition, int width) {
            newposition.height = 18f;
            newposition.width = position.width / 11;
            for (int i = -1; i < width; i++) {
                if (i == -1) {
                    EditorGUI.LabelField(newposition, new GUIContent(""));
                    newposition.x += newposition.x + (position.width / 22);
                } else {
                    EditorGUI.LabelField(newposition, new GUIContent((i + 1) + ""));
                    newposition.x += newposition.width;
                }

            }
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label) {
            if (showPosition) {
                return 490;
            } else {
                return 18;
            }

        }
    }

}

