Information about the code in this folder

For BATU ta BATU, I created a big Scriptable Object class which had some Property Drawers that ease a lot the game level data management from the editor. I created different visualizations of arrays for the editor to manage all the time/points/colors data of every level in the game (hundreds of them). This saved me huge amount of time and managing the arrays became much easier and more intuitive. 

The .cs files are two of the Property Drawers used and the picture shows how the Scriptable Object looks in the Unity Editor