﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace EZSD {

    [CustomPropertyDrawer(typeof(BaseDataArray))]
    public class BaseDataPropertyDrawer : PropertyDrawer {
        public bool showPosition = true;
        Rect newposition;
        //int diff = 0;

        int allTimes = 0;
        int allCoins = 0;

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label) {
            allTimes = 0;
            allCoins = 0;

            newposition = position;
            SerializedProperty times = property.FindPropertyRelative("times");
            SerializedProperty coins = property.FindPropertyRelative("coins");
            SerializedProperty colors = property.FindPropertyRelative("colors");
            //SerializedProperty p = property;
            GUIStyle style = new GUIStyle();
            float timesCoinsPos = newposition.y;

            


            newposition.y += 18f;
            AddTopLabels(position, newposition);

            newposition.y += 18f;
            newposition.width = position.width / 22;
            newposition.height = 18f;
            for (int j = times.arraySize - 1; j >= 0; j--) {
                SerializedProperty timesCols = times.GetArrayElementAtIndex(j).FindPropertyRelative("cols");
                SerializedProperty coinsCols = coins.GetArrayElementAtIndex(j).FindPropertyRelative("cols");
                SerializedProperty colorsCols = colors.GetArrayElementAtIndex(j).FindPropertyRelative("cols");

                for (int i = -1; i < timesCols.arraySize; i++) {
                    if (i == -1) {
                        EditorGUI.LabelField(new Rect(newposition.x, newposition.y, 80, newposition.height), new GUIContent((j + 3) + ""));
                        newposition.x += 20;
                    } else {
                        if (j <= i) {
                            GUI.color = new Color(0.8f, 0.8f, 0.96f);
                            EditorGUI.PropertyField(new Rect(newposition.x, newposition.y, 55, 18), timesCols.GetArrayElementAtIndex(i), GUIContent.none);
                            allTimes += timesCols.GetArrayElementAtIndex(i).intValue;
                            GUI.color = new Color(0.8f, 0.96f, 0.8f);
                            EditorGUI.PropertyField(new Rect(newposition.x + 25, newposition.y, 55, 18), coinsCols.GetArrayElementAtIndex(i), GUIContent.none);
                            allCoins += coinsCols.GetArrayElementAtIndex(i).intValue;
                            GUI.color = new Color(0.96f, 0.8f, 0.8f);
                            EditorGUI.PropertyField(new Rect(newposition.x + 50, newposition.y, 45, 18), colorsCols.GetArrayElementAtIndex(i), GUIContent.none);
                        }
                        newposition.x += 67;
                    }
                }
                newposition.x = position.x;
                newposition.y += 18f;
            }
            GUI.color = Color.white;

            style.normal.textColor = new Color(0.4f, 0.4f, 0.96f);
            EditorGUI.LabelField(new Rect(position.x, timesCoinsPos, 100, newposition.height), new GUIContent("Times (" + allTimes + ")"), style);
            style.normal.textColor = new Color(0.2f, 0.7f, 0.2f);
            EditorGUI.LabelField(new Rect(100, timesCoinsPos, 100, newposition.height), new GUIContent("Coins (" + allCoins + ") + (" + (allCoins / 4 ) + ")"), style);
            style.normal.textColor = new Color(0.7f, 0.2f, 0.2f);
            EditorGUI.LabelField(new Rect(234, timesCoinsPos, 100, newposition.height), new GUIContent("Colors"), style);

            if (property.FindPropertyRelative("groupCountToCompletes") != null)
                newposition = AddGrid(position, newposition, property.FindPropertyRelative("groupCountToCompletes"), "Group Count to Complete");
            if (property.FindPropertyRelative("minimumGroupCounts") != null)
                newposition = AddGrid(position, newposition, property.FindPropertyRelative("minimumGroupCounts"), "Minimum Group Counts");
            if (property.FindPropertyRelative("cubeStackSizes") != null)
                newposition = AddGrid(position, newposition, property.FindPropertyRelative("cubeStackSizes"), "Cube Stack Sizes");
            if (property.FindPropertyRelative("colorsToRemove") != null)
                newposition = AddGrid(position, newposition, property.FindPropertyRelative("colorsToRemove"), "Colors to Remove");
            if (property.FindPropertyRelative("colorsToEat") != null)
                newposition = AddGrid(position, newposition, property.FindPropertyRelative("colorsToEat"), "Colors to Eat");
            /*}
        } 
        if (!Selection.activeTransform) {
            showPosition = false;
        }*/
            EditorGUI.DrawRect(new Rect(position.x, newposition.y + 10, position.width, 1), Color.gray);

        }

        private void AddTopLabels(Rect position, Rect newposition) {
            newposition.height = 18f;
            newposition.width = 80;
            for (int i = -1; i < 10; i++) {
                if (i == -1) {
                    EditorGUI.LabelField(newposition, new GUIContent(""));
                    newposition.x += newposition.x + 30;
                } else {
                    EditorGUI.LabelField(newposition, new GUIContent((i + 3) + ""));
                    newposition.x += 67;
                }

            }
        }

        private Rect AddGrid(Rect position, Rect newposition, SerializedProperty data, string text) {
            float oldPositionY = newposition.y;

            if (data != null) {
                if (data.arraySize != 0) {
                    newposition.y += 18f;
                    EditorGUI.LabelField(new Rect(newposition.x, newposition.y, 200, newposition.height), new GUIContent(text));
                    newposition.y += 18f;


                    AddTopLabels(position, newposition);
                    newposition.x = position.x;
                    newposition.y += 18f;

                    for (int j = data.arraySize - 1; j >= 0; j--) {

                        SerializedProperty cols = data.GetArrayElementAtIndex(j).FindPropertyRelative("cols");
                        newposition.height = 18f;
                        newposition.width = position.width / 11;

                        for (int i = -1; i < cols.arraySize; i++) {
                            if (i == -1) {
                                EditorGUI.LabelField(new Rect(newposition.x, newposition.y, 80, newposition.height), new GUIContent((j + 3) + ""));
                                newposition.x += 20;
                            } else {
                                if (j <= i) {
                                    EditorGUI.PropertyField(new Rect(newposition.x, newposition.y, 88, 18), cols.GetArrayElementAtIndex(i), GUIContent.none);
                                    //EditorGUI.PropertyField(newposition, cols.GetArrayElementAtIndex(i), GUIContent.none);
                                }
                                newposition.x += 67;
                            }
                        }

                        newposition.x = position.x;
                        newposition.y += 18f;
                    }


                }
            }
            

            return newposition;
        }

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label) {
            if (showPosition) {
                int height = 280;
                if (property.FindPropertyRelative("groupCountToCompletes").arraySize != 0) {
                    height += 240;
                }
                if (property.FindPropertyRelative("minimumGroupCounts").arraySize != 0) {
                    height += 240;
                }
                if (property.FindPropertyRelative("cubeStackSizes").arraySize != 0) {
                    height += 240;
                }
                if (property.FindPropertyRelative("colorsToRemove").arraySize != 0) {
                    height += 240;
                }
                if (property.FindPropertyRelative("colorsToEat").arraySize != 0) {
                    height += 240;
                }

                return height;
            } else {
                return 18;
            }

        }
    }
}